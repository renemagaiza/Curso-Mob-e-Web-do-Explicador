<?php

/*
|--------------------------------------------------------------------------
| Nova Language Lines
|--------------------------------------------------------------------------
|
| The following language lines contain the default error messages used by
| the validator class. Some of these rules have multiple versions such
| as the size rules. Feel free to tweak each of these messages here.
|
*/

return [
    'attached'  => 'Kjo fushë është e ngjitur.',
    'relatable' => 'Kjo fushë mund të mos shoqërohet me këtë burim.',
];
