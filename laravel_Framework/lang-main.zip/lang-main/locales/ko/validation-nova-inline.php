<?php

/*
|--------------------------------------------------------------------------
| Nova Language Lines
|--------------------------------------------------------------------------
|
| The following language lines contain the default error messages used by
| the validator class. Some of these rules have multiple versions such
| as the size rules. Feel free to tweak each of these messages here.
|
*/

return [
    'attached'  => '이 필드는 이미 첨부되어 있습니다.',
    'relatable' => '이 필드는이 리소스와 연결되지 않을 수도 있습니다.',
];
