<?php

/*
|--------------------------------------------------------------------------
| Nova Language Lines
|--------------------------------------------------------------------------
|
| The following language lines contain the default error messages used by
| the validator class. Some of these rules have multiple versions such
| as the size rules. Feel free to tweak each of these messages here.
|
*/

return [
    'attached'  => ':attribute ត្រូវបានភ្ជាប់រួចទៅហើយ។',
    'relatable' => ':attribute មិនអាចត្រូវបានភ្ជាប់ជាមួយនឹងធនធាននេះ។',
];
