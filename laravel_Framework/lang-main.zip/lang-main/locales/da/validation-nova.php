<?php

/*
|--------------------------------------------------------------------------
| Nova Language Lines
|--------------------------------------------------------------------------
|
| The following language lines contain the default error messages used by
| the validator class. Some of these rules have multiple versions such
| as the size rules. Feel free to tweak each of these messages here.
|
*/

return [
    'attached'  => 'Denne :attribute er allerede vedhæftet.',
    'relatable' => 'Denne :attribute er muligvis ikke knyttet til denne ressource.',
];
